using System.Diagnostics;
using Microsoft.Maui.Storage;

namespace PhilipPuzotryas;

public partial class MainPage : ContentPage
{
    // ==================== ФИЗИКА ====================
    private double velocityX = 0;
    private double velocityY = 0;

    // Коэффициент трения (чем ближе к 1.0 — тем дольше скользит как по льду)
    private const double Friction = 0.968;

    // Сила отскока от стен
    private const double Bounce = 0.75;

    // Минимальная скорость, ниже которой останавливаем
    private const double MinVelocity = 0.12;

    private bool isDragging = false;
    private bool physicsRunning = false;

    private Stopwatch velocityTimer = new();
    private Point previousPoint;

    private double screenWidth;
    private double screenHeight;

    public MainPage()
    {
        InitializeComponent();

        // Проверяем, был ли уже первый запуск приложения
        bool hasOpenedBefore = Preferences.Default.Get("HasOpenedBefore", false);

        if (!hasOpenedBefore)
        {
            // Первый запуск — показываем текст
            TitleLabel.IsVisible = true;

            // Запоминаем, что уже открывали
            Preferences.Default.Set("HasOpenedBefore", true);

            // Добавляем жест перетаскивания
            var panGesture = new PanGestureRecognizer();
            panGesture.PanUpdated += OnPanUpdated;
            TitleLabel.GestureRecognizers.Add(panGesture);
        }
        else
        {
            // Повторный запуск — текст не показываем
            TitleLabel.IsVisible = false;
        }
    }

    protected override void OnSizeAllocated(double width, double height)
    {
        base.OnSizeAllocated(width, height);

        if (width > 0 && height > 0)
        {
            screenWidth = width;
            screenHeight = height;
        }
    }

    private void OnPanUpdated(object? sender, PanUpdatedEventArgs e)
    {
        if (!TitleLabel.IsVisible)
            return;

        switch (e.StatusType)
        {
            case GestureStatus.Started:
                isDragging = true;
                velocityX = 0;
                velocityY = 0;
                velocityTimer.Restart();
                previousPoint = new Point(e.TotalX, e.TotalY);
                break;

            case GestureStatus.Running:
                // Получаем текущие границы
                var bounds = AbsoluteLayout.GetLayoutBounds(TitleLabel);

                double newX = bounds.X + e.TotalX;
                double newY = bounds.Y + e.TotalY;

                // Ограничиваем перемещение границами экрана
                double labelWidth = TitleLabel.Width > 0 ? TitleLabel.Width : 280;
                double labelHeight = TitleLabel.Height > 0 ? TitleLabel.Height : 70;

                newX = Math.Clamp(newX, 0, Math.Max(0, screenWidth - labelWidth));
                newY = Math.Clamp(newY, 0, Math.Max(0, screenHeight - labelHeight));

                // Перемещаем
                AbsoluteLayout.SetLayoutBounds(TitleLabel,
                    new Rect(newX, newY, AbsoluteLayout.AutoSize, AbsoluteLayout.AutoSize));
                AbsoluteLayout.SetLayoutFlags(TitleLabel, AbsoluteLayoutFlags.None);

                // Вычисляем скорость для инерции
                var current = new Point(e.TotalX, e.TotalY);
                double dt = velocityTimer.Elapsed.TotalSeconds;

                if (dt > 0.008)
                {
                    // Масштаб скорости (подбирается экспериментально)
                    velocityX = (current.X - previousPoint.X) / dt * 0.016;
                    velocityY = (current.Y - previousPoint.Y) / dt * 0.016;

                    previousPoint = current;
                    velocityTimer.Restart();
                }
                break;

            case GestureStatus.Completed:
            case GestureStatus.Canceled:
                isDragging = false;
                StartPhysics();
                break;
        }
    }

    private void StartPhysics()
    {
        if (physicsRunning)
            return;

        physicsRunning = true;

        // ~60 FPS
        Dispatcher.StartTimer(TimeSpan.FromMilliseconds(16), () =>
        {
            if (isDragging || !TitleLabel.IsVisible)
            {
                physicsRunning = false;
                return false;
            }

            // Применяем трение (эффект "льда")
            velocityX *= Friction;
            velocityY *= Friction;

            // Останавливаем, если почти не движется
            if (Math.Abs(velocityX) < MinVelocity && Math.Abs(velocityY) < MinVelocity)
            {
                velocityX = 0;
                velocityY = 0;
                physicsRunning = false;
                return false;
            }

            var bounds = AbsoluteLayout.GetLayoutBounds(TitleLabel);
            double labelWidth = TitleLabel.Width > 0 ? TitleLabel.Width : 280;
            double labelHeight = TitleLabel.Height > 0 ? TitleLabel.Height : 70;

            double x = bounds.X + velocityX;
            double y = bounds.Y + velocityY;

            // Отскок от левой/правой стены
            if (x < 0)
            {
                x = 0;
                velocityX = -velocityX * Bounce;
            }
            else if (x + labelWidth > screenWidth)
            {
                x = screenWidth - labelWidth;
                velocityX = -velocityX * Bounce;
            }

            // Отскок от верхней/нижней стены
            if (y < 0)
            {
                y = 0;
                velocityY = -velocityY * Bounce;
            }
            else if (y + labelHeight > screenHeight)
            {
                y = screenHeight - labelHeight;
                velocityY = -velocityY * Bounce;
            }

            AbsoluteLayout.SetLayoutBounds(TitleLabel,
                new Rect(x, y, AbsoluteLayout.AutoSize, AbsoluteLayout.AutoSize));

            return true; // продолжаем таймер
        });
    }
}
